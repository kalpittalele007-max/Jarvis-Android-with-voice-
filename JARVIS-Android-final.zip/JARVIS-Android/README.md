# JARVIS Android AI

A modular AI-agent foundation designed for an Android phone running Termux.

JARVIS is intentionally built around:

**voice/text input → planner → structured tool calls → safe execution → verification → response**

It is not a giant collection of hard-coded voice-command `if` statements. The planner selects registered tools, while the tool registry controls what can actually execute.

## Features

- Natural-language conversation with bounded session memory
- Optional external LLM planner using environment variables
- Strict JSON/action validation before tool execution
- Local fallback planner when no AI backend is configured
- Termux speech input/output with typed fallback
- Safe Android intent integration
- Tool registry with schemas and confirmation requirements
- URL, app, file and Downloads operations
- Parametric futuristic **visualization/CAD** rocket generator
- High-resolution OpenSCAD model
- STL rendering with verification
- Independent 2D drawing engine
- Explicit confirmation gate for consequential actions
- Extensible Android controller interface for a future Accessibility companion

> The rocket model is a visual/CAD model only. It does not include propulsion, flight performance, guidance, or real-world weapon/vehicle construction guidance.

---

## Architecture

```text
VOICE INPUT / TEXT INPUT
          ↓
      JARVIS CORE
          ↓
   AI / LOCAL PLANNER
          ↓
 STRUCTURED TOOL ACTIONS
          ↓
     TOOL REGISTRY
          ↓
 TOOL EXECUTION + VERIFY
          ↓
    VOICE RESPONSE
```

Main modules:

```text
JARVIS-Android/
├── jarvis.py
├── config.py
├── requirements.txt
├── README.md
├── .gitignore
├── setup.sh
├── core/
├── voice/
├── android/
├── tools/
├── drawing/
├── modeling/
└── output/
```

## Installation in Termux

### 1. Clone or copy the project

```bash
git clone https://github.com/kalpittalele007-max/Jarvis-Android-with-voice-.git
cd Jarvis-Android-with-voice-
```

If you upload this generated project under another repository folder, `cd` into that folder instead.

### 2. Run setup

```bash
chmod +x setup.sh
./setup.sh
```

Or install manually:

```bash
pkg update
pkg install python git openscad
pkg install termux-api
termux-setup-storage
```

### 3. Start JARVIS

```bash
python jarvis.py
```

Type `/voice` to attempt speech input.

## Voice setup

Install the **Termux:API Android companion application** matching your Termux installation source, then install:

```bash
pkg install termux-api
```

JARVIS detects `termux-speech-to-text` and `termux-tts-speak`.

If unavailable, JARVIS automatically falls back to typed input.

## Optional AI planner

No API key is required to start JARVIS. Without an AI backend, the local fallback handles basic built-in capabilities.

For an external OpenAI-compatible chat-completions-style endpoint:

```bash
export JARVIS_API_KEY="your-secret-key"
export JARVIS_API_URL="https://your-provider.example/v1/chat/completions"
export JARVIS_MODEL="your-model-name"
```

Do not commit these values. `.env` is ignored by Git, but this project intentionally does not auto-load dotenv to keep dependencies minimal. Export variables in your shell or source a private shell file.

The planner asks the model for JSON shaped like:

```json
{
  "reply": "I'll build the 3D rocket.",
  "actions": [
    {
      "tool": "build_rocket",
      "args": {"windows": 6, "fins": 4},
      "needs_confirmation": false
    }
  ]
}
```

Malformed model output is rejected and safely replaced by the local planner.

## Example commands

- `JARVIS, build me a futuristic rocket.`
- `Make that rocket longer and give it six windows.`
- `Open my rocket.`
- `Draw me a rocket.`
- `What time is it?`
- `List my downloads.`
- `Open YouTube.`
- `Open https://example.com`

## 3D rocket generation

The generator creates:

```text
~/storage/downloads/JARVIS_rocket_3D.scad
~/storage/downloads/JARVIS_rocket_3D.stl
```

The SCAD model is parametric and supports:

- body length
- body radius
- nose length
- windows
- fins
- fin size
- fin position
- detail rings

Rendering is validated:

1. SCAD existence
2. OpenSCAD availability
3. process execution
4. return code
5. STL existence
6. non-zero STL size

If OpenSCAD is unavailable, JARVIS still generates the `.scad` source and clearly reports that STL rendering could not run.

## Android automation design

`AndroidController` exposes:

- `open_app()`
- `open_url()`
- `open_file()`
- `get_screen()`
- `tap()`
- `type_text()`
- `swipe()`

Plain Termux does not provide unrestricted UI automation. Intent-based operations work where Android supports them. Screen reading and gestures return **not available** until a future Accessibility-service companion is connected.

## Confirmation system

Consequential actions are not silently executed. The architecture supports pending actions and requires an explicit confirmation response such as:

```text
Send it?
> yes
```

The current built-in tools avoid message sending, purchases, calls, posting, deletion, and account actions. Any future tool marked `requires_confirmation=True` automatically enters the confirmation gate.

## Limitations

- Android app package names vary by device.
- Android file opening depends on installed apps and Android URI permissions.
- `am start` may not support every file MIME type.
- OpenSCAD availability depends on the Termux repository/device architecture.
- Advanced screen control requires an Accessibility companion; plain Python cannot reliably inspect arbitrary Android UI.

## Code validation

Run:

```bash
python -m compileall -q .
```

This project uses only the Python standard library.
