from __future__ import annotations

APP_PACKAGES = {
    "youtube": "com.google.android.youtube",
    "chrome": "com.android.chrome",
    "settings": "com.android.settings",
}

def resolve_package(app_name: str) -> str | None:
    normalized = app_name.strip().lower()
    return APP_PACKAGES.get(normalized)
