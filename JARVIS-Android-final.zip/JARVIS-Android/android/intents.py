from __future__ import annotations
import mimetypes
import shutil
import subprocess
from pathlib import Path
from android.apps import resolve_package
from android.screen import ScreenAutomation, CapabilityResult

class AndroidController:
    def __init__(self) -> None:
        self.screen = ScreenAutomation()
        self.am = shutil.which("am")
        self.termux_open = shutil.which("termux-open")

    def _run(self, command: list[str]) -> CapabilityResult:
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=20, check=False)
            if result.returncode == 0:
                return CapabilityResult(True, "Android intent launched.")
            return CapabilityResult(False, result.stderr.strip() or result.stdout.strip() or "Android command failed.")
        except (OSError, subprocess.TimeoutExpired) as exc:
            return CapabilityResult(False, f"Android capability unavailable: {exc}")

    def open_app(self, app: str) -> CapabilityResult:
        package = resolve_package(app) or app.strip()
        if not self.am:
            return CapabilityResult(False, "Android app launching is not available in this environment.")
        return self._run([self.am, "start", "-n", package] if "/" in package else [self.am, "start", "-p", package])

    def open_url(self, url: str) -> CapabilityResult:
        if not url.startswith(("http://", "https://")):
            return CapabilityResult(False, "Only http and https URLs are supported.")
        if self.termux_open:
            return self._run([self.termux_open, url])
        if self.am:
            return self._run([self.am, "start", "-a", "android.intent.action.VIEW", "-d", url])
        return CapabilityResult(False, "URL opening is not available.")

    def open_file(self, path: Path) -> CapabilityResult:
        if not path.exists():
            return CapabilityResult(False, f"File not found: {path}")
        if self.termux_open:
            return self._run([self.termux_open, str(path)])
        return CapabilityResult(False, "File opening is not available. Install Termux:API or an Android intent helper.")

    def get_screen(self) -> CapabilityResult:
        return self.screen.unavailable("Screen capture")

    def tap(self, x: int, y: int) -> CapabilityResult:
        return self.screen.unavailable("Tap automation")

    def type_text(self, text: str) -> CapabilityResult:
        return self.screen.unavailable("Text injection")

    def swipe(self, *args: int) -> CapabilityResult:
        return self.screen.unavailable("Swipe automation")
