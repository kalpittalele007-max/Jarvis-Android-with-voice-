from __future__ import annotations
from dataclasses import dataclass

@dataclass
class CapabilityResult:
    ok: bool
    message: str

class ScreenAutomation:
    def unavailable(self, action: str) -> CapabilityResult:
        return CapabilityResult(
            False,
            f"{action} is not available in plain Termux. An Accessibility companion is required."
        )
