from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class Config:
    api_key: str | None
    api_url: str | None
    model: str | None
    downloads_dir: Path
    max_history: int = 16
    request_timeout: int = 30
    render_timeout: int = 120

    @classmethod
    def from_env(cls) -> "Config":
        home = Path.home()
        downloads = Path(os.getenv("JARVIS_DOWNLOADS_DIR", home / "storage" / "downloads")).expanduser()
        return cls(
            api_key=os.getenv("JARVIS_API_KEY"),
            api_url=os.getenv("JARVIS_API_URL"),
            model=os.getenv("JARVIS_MODEL"),
            downloads_dir=downloads,
            max_history=int(os.getenv("JARVIS_MAX_HISTORY", "16")),
            request_timeout=int(os.getenv("JARVIS_REQUEST_TIMEOUT", "30")),
            render_timeout=int(os.getenv("JARVIS_RENDER_TIMEOUT", "120")),
        )
