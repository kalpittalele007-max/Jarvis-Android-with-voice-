from __future__ import annotations
from core.memory import SessionMemory
from core.planner import Planner
from core.safety import ConfirmationGate
from voice.input import VoiceInput
from voice.output import VoiceOutput
from android.intents import AndroidController
from tools.registry import ToolRegistry
from tools.files import register_file_tools
from tools.web import register_web_tools
from tools.system import register_system_tools
from drawing.drawing_engine import register_drawing_tools
from modeling.rocket import register_modeling_tools

class JarvisAssistant:
    def __init__(self, config) -> None:
        self.config = config
        self.memory = SessionMemory(config.max_history)
        self.voice_in = VoiceInput()
        self.voice_out = VoiceOutput()
        self.android = AndroidController()
        self.registry = ToolRegistry()
        self.gate = ConfirmationGate()

        register_file_tools(self.registry, config, self.memory, self.android)
        register_web_tools(self.registry, self.android)
        register_system_tools(self.registry)
        register_drawing_tools(self.registry, config)
        register_modeling_tools(self.registry, config, self.memory)

        self.planner = Planner(config, self.registry)

    def run(self) -> None:
        print("JARVIS Android AI ready. Type /voice for speech, /quit to exit.")
        self.voice_out.say("JARVIS online.")
        while True:
            text = self.voice_in.get_input()
            if text is None:
                continue
            if text.strip().lower() in {"/quit", "quit", "exit"}:
                self.voice_out.say("Shutting down. Goodbye.")
                break
            if not text.strip():
                continue
            self.handle(text)

    def handle(self, text: str) -> None:
        pending = self.gate.consume_if_confirmed(text)
        if pending:
            result = self.registry.execute(pending.tool, pending.args)
            self._respond(result.message)
            return
        if self.gate.has_pending() and text.strip().lower() in {"no", "n", "cancel", "stop"}:
            self._respond("Cancelled.")
            return

        self.memory.add("user", text)
        plan = self.planner.plan(text, self.memory)
        messages = [plan.reply]
        for action in plan.actions:
            tool = self.registry.get(action.tool)
            if self.gate.requires_confirmation(action.tool, tool.requires_confirmation or action.needs_confirmation):
                self.gate.set_pending(action.tool, action.args)
                messages.append(f"Prepared {action.tool}. Confirm execution?")
                continue
            result = self.registry.execute(action.tool, action.args)
            messages.append(result.message)
        response = " ".join(m for m in messages if m).strip()
        self.memory.add("assistant", response)
        self._respond(response)

    def _respond(self, message: str) -> None:
        print(f"JARVIS: {message}")
        self.voice_out.say(message)
