from __future__ import annotations
from collections import deque
from dataclasses import dataclass, field
from typing import Any

@dataclass
class SessionMemory:
    max_items: int = 16
    history: deque[dict[str, str]] = field(default_factory=deque)
    state: dict[str, Any] = field(default_factory=dict)

    def add(self, role: str, content: str) -> None:
        self.history.append({"role": role, "content": content})
        while len(self.history) > self.max_items:
            self.history.popleft()

    def recent(self) -> list[dict[str, str]]:
        return list(self.history)

    def remember_model(self, path: str, params: dict[str, Any]) -> None:
        self.state["last_model"] = {"path": path, "params": dict(params)}

    def last_model(self) -> dict[str, Any] | None:
        value = self.state.get("last_model")
        return value if isinstance(value, dict) else None
