from __future__ import annotations
import json
import re
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

@dataclass
class Action:
    tool: str
    args: dict[str, Any]
    needs_confirmation: bool = False

@dataclass
class Plan:
    reply: str
    actions: list[Action]

class Planner:
    def __init__(self, config: Any, registry: Any) -> None:
        self.config = config
        self.registry = registry

    def plan(self, user_text: str, memory: Any) -> Plan:
        if self.config.api_url and self.config.model:
            try:
                return self._remote_plan(user_text, memory)
            except Exception:
                pass
        return self._local_plan(user_text, memory)

    def _remote_plan(self, user_text: str, memory: Any) -> Plan:
        tools = self.registry.schemas()
        system = (
            "You are JARVIS, a safe Android AI agent. Return ONLY valid JSON with keys "
            "'reply' and 'actions'. actions is a list of {tool,args,needs_confirmation}. "
            "Choose only tools listed below. Never invent shell commands. "
            f"TOOLS={json.dumps(tools)}"
        )
        payload = {
            "model": self.config.model,
            "messages": [{"role": "system", "content": system}, *memory.recent(),
                         {"role": "user", "content": user_text}],
            "temperature": 0.2,
            "response_format": {"type": "json_object"},
        }
        data = json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(
            self.config.api_url,
            data=data,
            headers={
                "Content-Type": "application/json",
                **({"Authorization": f"Bearer {self.config.api_key}"} if self.config.api_key else {}),
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.config.request_timeout) as response:
                raw = json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError) as exc:
            raise RuntimeError("AI backend unavailable") from exc

        content = raw.get("choices", [{}])[0].get("message", {}).get("content", "")
        return self._validate_plan(json.loads(content))

    def _validate_plan(self, data: Any) -> Plan:
        if not isinstance(data, dict) or not isinstance(data.get("reply"), str):
            raise ValueError("Malformed planner response")
        raw_actions = data.get("actions", [])
        if not isinstance(raw_actions, list):
            raise ValueError("Actions must be a list")
        actions: list[Action] = []
        for item in raw_actions:
            if not isinstance(item, dict):
                raise ValueError("Invalid action")
            tool = item.get("tool")
            args = item.get("args", {})
            if not isinstance(tool, str) or not isinstance(args, dict):
                raise ValueError("Invalid action fields")
            if not self.registry.has(tool):
                raise ValueError(f"Unknown tool: {tool}")
            actions.append(Action(tool, args, bool(item.get("needs_confirmation", False))))
        return Plan(data["reply"], actions)

    def _local_plan(self, text: str, memory: Any) -> Plan:
        t = text.lower().strip()
        if "rocket" in t and any(word in t for word in ("build", "make", "create", "longer", "modify")):
            previous = (memory.last_model() or {}).get("params", {})
            windows = self._number_after(t, "window", previous.get("windows", 4))
            fins = self._number_after(t, "fin", previous.get("fins", 4))
            body_length = previous.get("body_length", 120.0)
            nose_length = previous.get("nose_length", 45.0)
            if "longer" in t:
                nose_length = float(nose_length) * 1.35
            args = {"windows": windows, "fins": fins, "body_length": body_length, "nose_length": nose_length}
            return Plan("I'll build the updated 3D rocket.", [Action("build_rocket", args)])
        if "draw" in t and "rocket" in t:
            return Plan("I'll create a rocket drawing.", [Action("draw_rocket", {})])
        if ("open" in t and ("rocket" in t or "model" in t)):
            return Plan("I'll try to open the latest rocket model.", [Action("open_file", {"path": "last_rocket"})])
        if t.startswith("open http") or "open url" in t:
            url = re.search(r"https?://\S+", text)
            return Plan("Opening the URL.", [Action("open_url", {"url": url.group(0) if url else ""})])
        if t.startswith("open "):
            return Plan("I'll try to open that app.", [Action("open_app", {"app": text[5:].strip()})])
        if "download" in t and ("list" in t or "show" in t):
            return Plan("I'll list your Downloads.", [Action("list_downloads", {})])
        if "time" in t:
            return Plan("I'll check the current time.", [Action("get_time", {})])
        return Plan(
            "AI planning is unavailable, so I can use local tools. Try asking me to build or draw a rocket, open an app or URL, list Downloads, or tell the time.",
            [],
        )

    @staticmethod
    def _number_after(text: str, word: str, default: int) -> int:
        match = re.search(r"(\d+)\s+" + re.escape(word), text)
        return int(match.group(1)) if match else int(default)
