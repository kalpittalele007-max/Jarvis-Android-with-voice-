from __future__ import annotations
from dataclasses import dataclass
from typing import Any

CONSEQUENTIAL_KEYWORDS = {
    "send", "message", "call", "purchase", "buy", "delete",
    "post", "comment", "follow", "change_settings",
}

@dataclass
class PendingAction:
    tool: str
    args: dict[str, Any]

class ConfirmationGate:
    def __init__(self) -> None:
        self.pending: PendingAction | None = None

    def requires_confirmation(self, tool_name: str, tool_requires_confirmation: bool) -> bool:
        return tool_requires_confirmation or tool_name in CONSEQUENTIAL_KEYWORDS

    def set_pending(self, tool: str, args: dict[str, Any]) -> None:
        self.pending = PendingAction(tool, args)

    def consume_if_confirmed(self, text: str) -> PendingAction | None:
        normalized = text.strip().lower()
        if self.pending and normalized in {"yes", "y", "confirm", "do it", "go ahead"}:
            action = self.pending
            self.pending = None
            return action
        if self.pending and normalized in {"no", "n", "cancel", "stop"}:
            self.pending = None
        return None

    def has_pending(self) -> bool:
        return self.pending is not None
