from __future__ import annotations
from pathlib import Path
from tools.registry import Tool, ToolResult

SVG = """<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="700" viewBox="0 0 1000 700">
<rect width="1000" height="700" fill="#07111f"/>
<g transform="translate(500 350)">
<path d="M-70,220 L-150,140 L-110,20 L-110,-110 C-110,-250 -55,-330 0,-380 C55,-330 110,-250 110,-110 L110,20 L150,140 L70,220 Z" fill="#c9d5df" stroke="#61dafb" stroke-width="8"/>
<path d="M0,-380 C-55,-330 -70,-260 -70,-160 L70,-160 C70,-260 55,-330 0,-380Z" fill="#f3f7fb"/>
<circle cx="0" cy="-70" r="42" fill="#13233a" stroke="#61dafb" stroke-width="8"/>
<circle cx="0" cy="45" r="25" fill="#13233a" stroke="#61dafb" stroke-width="6"/>
<path d="M-55,210 L-90,280 L-20,235 Z M55,210 L90,280 L20,235 Z" fill="#ff8c42"/>
</g><text x="500" y="650" text-anchor="middle" fill="#61dafb" font-family="sans-serif" font-size="34">JARVIS FUTURISTIC ROCKET</text>
</svg>"""

def register_drawing_tools(registry, config) -> None:
    def draw_rocket() -> ToolResult:
        config.downloads_dir.mkdir(parents=True, exist_ok=True)
        path = config.downloads_dir / "JARVIS_rocket_drawing.svg"
        path.write_text(SVG, encoding="utf-8")
        return ToolResult(True, f"Rocket drawing created: {path}", {"path": str(path)})

    registry.register(Tool("draw_rocket", "Create a clean 2D rocket drawing.", {}, draw_rocket))
