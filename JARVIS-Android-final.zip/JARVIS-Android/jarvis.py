#!/usr/bin/env python3
from config import Config
from core.assistant import JarvisAssistant

def main() -> None:
    assistant = JarvisAssistant(Config.from_env())
    assistant.run()

if __name__ == "__main__":
    main()
