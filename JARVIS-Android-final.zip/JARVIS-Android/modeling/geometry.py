from __future__ import annotations
from dataclasses import dataclass

@dataclass
class RocketParameters:
    body_length: float = 120.0
    body_radius: float = 20.0
    nose_length: float = 45.0
    windows: int = 4
    fins: int = 4
    fin_size: float = 32.0
    fin_position: float = 18.0
    detail_rings: int = 4

    def normalized(self) -> "RocketParameters":
        return RocketParameters(
            body_length=max(40.0, float(self.body_length)),
            body_radius=max(8.0, float(self.body_radius)),
            nose_length=max(15.0, float(self.nose_length)),
            windows=max(0, min(12, int(self.windows))),
            fins=max(0, min(8, int(self.fins))),
            fin_size=max(8.0, float(self.fin_size)),
            fin_position=max(0.0, float(self.fin_position)),
            detail_rings=max(0, min(12, int(self.detail_rings))),
        )
