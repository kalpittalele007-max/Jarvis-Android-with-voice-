from __future__ import annotations
import shutil
import subprocess
from pathlib import Path

class OpenSCADRenderer:
    def __init__(self, timeout: int = 120) -> None:
        self.timeout = timeout

    def render(self, scad_path: Path, stl_path: Path) -> tuple[bool, str]:
        if not scad_path.exists():
            return False, f"SCAD file does not exist: {scad_path}"
        executable = shutil.which("openscad")
        if not executable:
            return False, "OpenSCAD is not installed."
        try:
            result = subprocess.run(
                [executable, "-o", str(stl_path), str(scad_path)],
                capture_output=True, text=True, timeout=self.timeout, check=False
            )
        except subprocess.TimeoutExpired:
            return False, "OpenSCAD rendering timed out."
        except OSError as exc:
            return False, f"Could not start OpenSCAD: {exc}"
        if result.returncode != 0:
            detail = (result.stderr or result.stdout).strip()
            return False, f"OpenSCAD rendering failed: {detail}"
        if not stl_path.exists():
            return False, "OpenSCAD finished but no STL file was created."
        if stl_path.stat().st_size <= 0:
            return False, "OpenSCAD created an empty STL file."
        return True, f"Rendered STL: {stl_path}"
