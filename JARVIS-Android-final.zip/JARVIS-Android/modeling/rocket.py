from __future__ import annotations
from pathlib import Path
from modeling.geometry import RocketParameters
from modeling.renderer import OpenSCADRenderer
from tools.registry import Tool, ToolResult

def scad_source(p: RocketParameters) -> str:
    p = p.normalized()
    # Visualization-only parametric CAD geometry. No propulsion or flight systems.
    lines = [
        "$fn = 96;",
        "",
        f"body_len = {p.body_length};",
        f"r = {p.body_radius};",
        f"nose_len = {p.nose_length};",
        f"window_count = {p.windows};",
        f"fin_count = {p.fins};",
        f"fin_size = {p.fin_size};",
        f"fin_pos = {p.fin_position};",
        f"ring_count = {p.detail_rings};",
        "",
        "module hull_segment(z0, z1, r0, r1) {",
        "    translate([0,0,z0]) cylinder(h=z1-z0, r1=r0, r2=r1);",
        "}",
        "",
        "// Smooth ogive-like revolved nose profile",
        "module ogive_nose() {",
        "    rotate_extrude(convexity=10)",
        "        polygon(points=concat(",
        "            [[0, body_len],",
        "             [r, body_len],",
        "             [r*0.995, body_len + nose_len*0.08],",
        "             [r*0.94, body_len + nose_len*0.25],",
        "             [r*0.78, body_len + nose_len*0.48],",
        "             [r*0.52, body_len + nose_len*0.72],",
        "             [r*0.22, body_len + nose_len*0.92],",
        "             [0, body_len + nose_len]],",
        "            [[0, body_len]]));",
        "}",
        "",
        "module body_shell() {",
        "    union() {",
        "        hull_segment(0, body_len*0.08, r*0.82, r);",
        "        cylinder(h=body_len*0.92, r=r);",
        "        ogive_nose();",
        "    }",
        "}",
        "",
        "module detail_ring(z) {",
        "    difference() {",
        "        translate([0,0,z]) cylinder(h=2.2, r=r*1.035);",
        "        translate([0,0,z-0.2]) cylinder(h=2.6, r=r*0.985);",
        "    }",
        "}",
        "",
        "module viewport(z, a) {",
        "    rotate([0,0,a])",
        "        translate([r*0.93,0,z])",
        "            rotate([0,90,0])",
        "                difference() {",
        "                    cylinder(h=r*0.14, r=r*0.23, center=true);",
        "                    translate([0,0,-r*0.09]) cylinder(h=r*0.12, r=r*0.17, center=true);",
        "                }",
        "}",
        "",
        "module fin() {",
        "    // Tapered swept visual fin",
        "    linear_extrude(height=r*0.22, center=true)",
        "        polygon(points=[[0,0],[fin_size,fin_size*0.22],[fin_size*0.72,fin_size*0.78],[-fin_size*0.18,fin_size*0.50]]);",
        "}",
        "",
        "module engine_nozzle() {",
        "    difference() {",
        "        translate([0,0,-r*0.55]) cylinder(h=r*0.55, r1=r*0.72, r2=r*0.55);",
        "        translate([0,0,-r*0.58]) cylinder(h=r*0.48, r=r*0.42);",
        "    }",
        "    for (a=[0:90:270]) rotate([0,0,a]) translate([r*0.5,0,-r*0.22]) cylinder(h=r*0.18, r=r*0.13);",
        "}",
        "",
        "union() {",
        "    body_shell();",
        "    engine_nozzle();",
        "    for (i=[0:ring_count-1]) detail_ring(body_len*(0.18 + i*0.14));",
        "    for (i=[0:window_count-1]) viewport(body_len*(0.50 + i*0.075), (i%2)*180);",
        "    for (i=[0:fin_count-1]) {",
        "        rotate([0,0,360/fin_count*i])",
        "            translate([r*0.78,0,fin_pos])",
        "                rotate([0,90,0]) fin();",
        "    }",
        "}",
    ]
    return "\n".join(lines) + "\n"

def register_modeling_tools(registry, config, memory) -> None:
    def build_rocket(
        body_length: float = 120.0,
        body_radius: float = 20.0,
        nose_length: float = 45.0,
        windows: int = 4,
        fins: int = 4,
        fin_size: float = 32.0,
        fin_position: float = 18.0,
        detail_rings: int = 4,
    ) -> ToolResult:
        params = RocketParameters(
            body_length, body_radius, nose_length, windows, fins,
            fin_size, fin_position, detail_rings
        ).normalized()
        config.downloads_dir.mkdir(parents=True, exist_ok=True)
        scad_path = config.downloads_dir / "JARVIS_rocket_3D.scad"
        stl_path = config.downloads_dir / "JARVIS_rocket_3D.stl"
        scad_path.write_text(scad_source(params), encoding="utf-8")
        if not scad_path.exists() or scad_path.stat().st_size == 0:
            return ToolResult(False, "Failed to create the SCAD model.")
        memory.remember_model(str(scad_path), params.__dict__)
        renderer = OpenSCADRenderer(config.render_timeout)
        ok, message = renderer.render(scad_path, stl_path)
        if ok:
            return ToolResult(True, f"3D rocket complete. SCAD: {scad_path}. STL: {stl_path}", {"scad": str(scad_path), "stl": str(stl_path)})
        return ToolResult(False, f"SCAD model created: {scad_path}. {message}", {"scad": str(scad_path)})

    def render_rocket() -> ToolResult:
        last = memory.last_model()
        if not last:
            return ToolResult(False, "No rocket model exists in this session yet.")
        scad_path = Path(last["path"])
        stl_path = scad_path.with_suffix(".stl")
        ok, message = OpenSCADRenderer(config.render_timeout).render(scad_path, stl_path)
        return ToolResult(ok, message)

    registry.register(Tool(
        "build_rocket",
        "Build a polished parametric futuristic visualization rocket and render STL.",
        {"body_length":"number","body_radius":"number","nose_length":"number","windows":"integer","fins":"integer","fin_size":"number","fin_position":"number","detail_rings":"integer"},
        build_rocket
    ))
    registry.register(Tool("render_rocket", "Render the latest rocket SCAD into STL.", {}, render_rocket))
