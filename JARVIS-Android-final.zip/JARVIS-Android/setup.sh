#!/data/data/com.termux/files/usr/bin/bash
set -eu

echo "[1/5] Updating Termux packages..."
pkg update -y
pkg upgrade -y

echo "[2/5] Installing Python, Git, and OpenSCAD..."
pkg install -y python git openscad

echo "[3/5] Preparing shared storage access..."
termux-setup-storage || true

echo "[4/5] Installing optional Termux API command package..."
pkg install -y termux-api || true

echo "[5/5] Validating Python source..."
python -m compileall -q .

echo
echo "Setup complete."
echo "For voice features, also install the Termux:API Android companion app."
echo "Then run: python jarvis.py"
