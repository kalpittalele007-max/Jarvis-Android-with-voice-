from __future__ import annotations
from pathlib import Path
from tools.registry import Tool, ToolResult

def register_file_tools(registry, config, memory, android) -> None:
    def list_downloads() -> ToolResult:
        directory = config.downloads_dir
        if not directory.exists():
            return ToolResult(False, f"Downloads directory does not exist: {directory}")
        items = sorted(p.name for p in directory.iterdir())[:50]
        return ToolResult(True, "Downloads: " + (", ".join(items) if items else "empty"), {"items": items})

    def open_file(path: str) -> ToolResult:
        if path == "last_rocket":
            last = memory.last_model()
            if not last:
                return ToolResult(False, "No rocket model exists in this session yet.")
            path = str(Path(last["path"]).with_suffix(".stl"))
            if not Path(path).exists():
                path = last["path"]
        result = android.open_file(Path(path).expanduser())
        return ToolResult(result.ok, result.message)

    registry.register(Tool("list_downloads", "List files in the Downloads directory.", {}, list_downloads))
    registry.register(Tool("open_file", "Open a file through Android when supported.", {"path": "string"}, open_file))
