from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable

@dataclass
class ToolResult:
    ok: bool
    message: str
    data: dict[str, Any] | None = None

@dataclass
class Tool:
    name: str
    description: str
    argument_schema: dict[str, Any]
    execute: Callable[..., ToolResult]
    requires_confirmation: bool = False

class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        if tool.name in self._tools:
            raise ValueError(f"Duplicate tool: {tool.name}")
        self._tools[tool.name] = tool

    def has(self, name: str) -> bool:
        return name in self._tools

    def get(self, name: str) -> Tool:
        return self._tools[name]

    def execute(self, name: str, args: dict[str, Any]) -> ToolResult:
        tool = self._tools.get(name)
        if not tool:
            return ToolResult(False, "That capability isn't installed yet.")
        try:
            return tool.execute(**args)
        except TypeError as exc:
            return ToolResult(False, f"Invalid arguments for {name}: {exc}")
        except Exception as exc:
            return ToolResult(False, f"{name} failed safely: {exc}")

    def schemas(self) -> list[dict[str, Any]]:
        return [{
            "name": tool.name,
            "description": tool.description,
            "arguments": tool.argument_schema,
            "requires_confirmation": tool.requires_confirmation,
        } for tool in self._tools.values()]
