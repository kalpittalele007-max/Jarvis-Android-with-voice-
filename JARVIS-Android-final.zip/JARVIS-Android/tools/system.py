from __future__ import annotations
from datetime import datetime
from tools.registry import Tool, ToolResult

def register_system_tools(registry) -> None:
    registry.register(Tool(
        "say", "Speak or display text.", {"text": "string"},
        lambda text: ToolResult(True, text)
    ))
    registry.register(Tool(
        "get_time", "Get the local system time.", {},
        lambda: ToolResult(True, datetime.now().strftime("The time is %I:%M %p."))
    ))
