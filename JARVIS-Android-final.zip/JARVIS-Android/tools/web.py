from __future__ import annotations
from tools.registry import Tool, ToolResult

def register_web_tools(registry, android) -> None:
    def open_url(url: str) -> ToolResult:
        result = android.open_url(url)
        return ToolResult(result.ok, result.message)

    def open_app(app: str) -> ToolResult:
        result = android.open_app(app)
        return ToolResult(result.ok, result.message)

    registry.register(Tool("open_url", "Open an http or https URL.", {"url": "string"}, open_url))
    registry.register(Tool("open_app", "Launch an Android application by known name or package.", {"app": "string"}, open_app))
