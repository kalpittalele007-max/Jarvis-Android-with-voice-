from __future__ import annotations
import shutil
import subprocess

class VoiceInput:
    def available(self) -> bool:
        return shutil.which("termux-speech-to-text") is not None

    def get_input(self) -> str | None:
        try:
            typed = input("You (/voice for speech): ").strip()
        except (EOFError, KeyboardInterrupt):
            return "/quit"
        if typed.lower() != "/voice":
            return typed
        if not self.available():
            print("Voice input isn't available. I'll use text input.")
            return input("You: ").strip()
        try:
            result = subprocess.run(
                ["termux-speech-to-text"],
                capture_output=True, text=True, timeout=30, check=False
            )
            if result.returncode == 0 and result.stdout.strip():
                text = result.stdout.strip()
                print(f"You (voice): {text}")
                return text
            print("Speech recognition failed. Please type your command.")
        except (subprocess.TimeoutExpired, OSError):
            print("Voice input isn't available. I'll use text input.")
        return input("You: ").strip()
