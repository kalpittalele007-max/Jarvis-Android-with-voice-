from __future__ import annotations
import shutil
import subprocess

class VoiceOutput:
    def __init__(self) -> None:
        self.command = shutil.which("termux-tts-speak")

    def say(self, text: str) -> None:
        if not self.command or not text:
            return
        try:
            subprocess.run(
                [self.command, "-r", "0.85", "-p", "0.9", text],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                timeout=20, check=False
            )
        except (OSError, subprocess.TimeoutExpired):
            pass
