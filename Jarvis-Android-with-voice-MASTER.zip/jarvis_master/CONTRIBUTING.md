# Contributing

Keep provider interfaces modular. Add mock tests before real integrations. Never commit credentials, personal data, OAuth tokens or private message content. Every consequential external action must pass through the approval manager.
