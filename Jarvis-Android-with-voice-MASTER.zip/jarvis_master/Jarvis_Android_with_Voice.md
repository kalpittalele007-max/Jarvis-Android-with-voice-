# JARVIS Android with Voice

See README.md for the modular implementation, Termux TTS/STT, email/message reading, approval-gated replies, dry-run mode and security boundaries.
