# JARVIS Android Termux Assistant

A modular, approval-controlled Android personal assistant for Python 3.11+ and Termux.

## Features
- Local Termux:API TTS and speech-to-text with graceful fallback.
- Owner phone call support.
- Read Android notification previews and SMS when Android/Termux permissions allow it.
- WhatsApp notification previews only. No private database scraping, encryption bypass, or accessibility bypass.
- Mock, Gmail API and Microsoft Graph email provider boundaries.
- Email reading/summarization/draft/reply workflow with approval before delivery.
- OpenAI-compatible AI boundary with explicit prompt-injection protection.
- SQLite persistence and UTC audit timestamps.
- Pune intelligence source framework with required source/URL/timestamp/location/status fields.
- Dry-run mode and mock providers.

## Install
Install Termux and the matching Termux:API Android companion. Then:

    pkg update
    pkg install python termux-api
    cd ~/JARVIS
    cp .env.example .env  # keep .env private; export variables as needed
    python jarvis.py status

## Voice

    python jarvis.py speak "JARVIS online"

`termux-tts-speak` is used when available. Speech recognition uses `termux-speech-to-text`; otherwise JARVIS falls back to typed input where applicable.

## Reading mail/messages

    python jarvis.py email inbox
    python jarvis.py email read 1
    python jarvis.py email summarize 1
    python jarvis.py sms list
    python jarvis.py whatsapp notifications

The bundled email inbox is a mock provider for credential-free testing. Configure official Gmail OAuth/API or Microsoft Graph tokens only through environment variables for real accounts.

## Reply workflow
JARVIS may generate a reply draft, but sending it is an approval-gated operation. The exact recipient, subject and body are shown before `APPROVE` can authorize it. Approval expires after 30 minutes and can be cancelled.

    python jarvis.py email draft --message 1
    python jarvis.py approvals
    python jarvis.py approve APPROVAL_ID

No message is sent merely because an email or WhatsApp notification was read.

## Calls

    python jarvis.py call-owner
    python jarvis.py call-person --name Rahul --number +91XXXXXXXXXX

Calling another person creates an approval; it does not automatically call them.

## Dry run

    python jarvis.py --dry-run speak "Test"
    python jarvis.py --dry-run call-owner

Dry-run mode never performs the external operation.

## Security
Credentials belong in environment variables and must never be committed. External email/message/web text is untrusted data and cannot override JARVIS instructions. See SECURITY.md.

## Limitations
Android background execution is constrained by battery optimization and OS process management. Continuous monitoring is therefore best-effort. WhatsApp private-app two-way automation is intentionally not implemented; use the official WhatsApp Business Platform for supported business messaging.
