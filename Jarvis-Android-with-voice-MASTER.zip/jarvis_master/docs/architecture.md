# Architecture

CLI -> configuration/database -> approval/audit layer -> local Android/provider adapters -> intelligence. External content is data, not instructions. Provider failures must not silently become successful actions.
