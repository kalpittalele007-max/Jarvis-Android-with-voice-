# Android permissions

Grant only permissions required for the features you use. Termux:API commands may require Android runtime permissions and notification access. Exact permission screens vary by Android version. Do not grant accessibility or device-admin privileges merely to make JARVIS appear more autonomous.
