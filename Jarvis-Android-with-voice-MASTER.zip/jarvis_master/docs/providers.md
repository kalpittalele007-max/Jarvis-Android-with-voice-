# Providers

Gmail: official Gmail API/OAuth. Outlook: official Microsoft Graph/OAuth. AI: OpenAI-compatible HTTP endpoint. WhatsApp: notification previews only unless the official WhatsApp Business Platform is configured. Never scrape the private WhatsApp application database.
