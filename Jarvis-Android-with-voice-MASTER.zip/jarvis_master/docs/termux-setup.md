# Termux setup

Install Termux and the matching Termux:API companion from a trusted source. Install `python` and `termux-api`. Verify with `which termux-tts-speak`, `which termux-speech-to-text`, `which termux-notification-list`, and `which termux-sms-list`. Android may suspend background work; monitoring is not guaranteed to remain alive indefinitely.
