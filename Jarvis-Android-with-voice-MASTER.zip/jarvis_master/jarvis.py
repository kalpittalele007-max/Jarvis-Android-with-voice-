#!/usr/bin/env python3
"""Backward-compatible root launcher for the modular JARVIS assistant."""
from jarvis.cli import main
if __name__=='__main__': main()
