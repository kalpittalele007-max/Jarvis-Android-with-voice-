import shutil,subprocess,json
from .security import validate_phone
class Android:
    def __init__(self,dry_run=False): self.dry_run=dry_run
    def available(self,tool): return shutil.which(tool) is not None
    def run(self,cmd):
        if self.dry_run: return {'dry_run':True,'command':cmd}
        try:
            p=subprocess.run(cmd,text=True,capture_output=True,timeout=60); return {'returncode':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()}
        except (FileNotFoundError,subprocess.TimeoutExpired) as e: return {'error':str(e)}
    def speak(self,text): return self.run(['termux-tts-speak','-r','0.85','-p','0.75',text]) if self.available('termux-tts-speak') else {'available':False}
    def call(self,number): validate_phone(number); return self.run(['termux-telephony-call',number])
    def notifications(self):
        r=self.run(['termux-notification-list']);
        try: return json.loads(r.get('stdout','[]')) if r.get('stdout') else r
        except json.JSONDecodeError: return r
    def sms(self):
        r=self.run(['termux-sms-list','-l','50']);
        try: return json.loads(r.get('stdout','[]')) if r.get('stdout') else r
        except json.JSONDecodeError: return r
    def sms_send(self,number,text): validate_phone(number); return self.run(['termux-sms-send','-n',number,text])
