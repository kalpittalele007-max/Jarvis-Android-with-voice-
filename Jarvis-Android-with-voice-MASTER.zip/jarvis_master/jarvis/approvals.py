import json,uuid
from datetime import datetime,timezone,timedelta
class ApprovalManager:
    def __init__(self,db,audit,ttl=30): self.db=db; self.audit=audit; self.ttl=timedelta(minutes=ttl)
    def create(self,kind,payload):
        now=datetime.now(timezone.utc); aid=uuid.uuid4().hex[:12]; exp=now+self.ttl
        self.db.execute('INSERT INTO approvals VALUES(?,?,?,?,?,?)',(aid,kind,json.dumps(payload,ensure_ascii=False),'pending',now.isoformat(),exp.isoformat()))
        self.audit.record('approval_created',{'id':aid,'kind':kind,'payload':payload}); return aid
    def expire(self): self.db.execute("UPDATE approvals SET status='expired' WHERE status='pending' AND expires_at<=?",(datetime.now(timezone.utc).isoformat(),))
    def pending(self): self.expire(); return self.db.rows("SELECT * FROM approvals WHERE status='pending'")
    def cancel(self,aid):
        self.db.execute("UPDATE approvals SET status='cancelled' WHERE id=? AND status='pending'",(aid,)); self.audit.record('approval_cancelled',{'id':aid}); return True
    def approve(self,aid):
        self.expire(); rows=self.db.rows('SELECT * FROM approvals WHERE id=?',(aid,))
        if not rows: raise ValueError('Approval not found')
        r=rows[0]
        if r['status']!='pending': raise ValueError('Approval is not pending')
        payload=json.loads(r['payload'])
        print('\nEXACT PAYLOAD:\n'+json.dumps(payload,indent=2,ensure_ascii=False))
        if input('\nType APPROVE exactly: ')!='APPROVE': self.cancel(aid); return False
        self.db.execute("UPDATE approvals SET status='approved' WHERE id=?",(aid,)); self.audit.record('approval_approved',{'id':aid,'kind':r['kind']}); return payload
