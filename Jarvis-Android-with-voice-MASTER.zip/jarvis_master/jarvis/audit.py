import json
from datetime import datetime, timezone
from .security import redact
class Audit:
    def __init__(self,db): self.db=db
    def record(self,event,data=None):
        self.db.execute('INSERT INTO audit_events(event,data,created_at) VALUES(?,?,?)',(event,json.dumps(redact(data or {}),ensure_ascii=False),datetime.now(timezone.utc).isoformat()))
