import argparse,json
from .config import Config
from .database import Database
from .audit import Audit
from .approvals import ApprovalManager
from .android import Android
from .voice.local_phone import LocalVoice
from .messaging.sms import SMSReader
from .messaging.whatsapp_notifications import WhatsAppNotifications
from .email.mock import MockEmail
from .pune.briefing import PuneBriefing

def main(argv=None):
 p=argparse.ArgumentParser(prog='jarvis'); p.add_argument('--dry-run',action='store_true'); s=p.add_subparsers(dest='c',required=True)
 for x in ('setup','status','notifications','approvals'):s.add_parser(x)
 x=s.add_parser('speak');x.add_argument('text')
 x=s.add_parser('call-owner')
 x=s.add_parser('call-person');x.add_argument('--name',required=True);x.add_argument('--number',required=True)
 s.add_parser('sms').add_argument('action',choices=['list'])
 s.add_parser('whatsapp').add_argument('action',choices=['notifications'])
 e=s.add_parser('email');e.add_argument('action',choices=['inbox','read','summarize','draft']);e.add_argument('message_id',nargs='?')
 for x in ('approve','cancel'):q=s.add_parser(x);q.add_argument('approval_id')
 q=s.add_parser('pune');q.add_argument('action',choices=['events','briefing'])
 q=s.add_parser('monitor');q.add_argument('action',choices=['once','run'])
 a=p.parse_args(argv);cfg=Config.load();db=Database(cfg.db_path);audit=Audit(db);ap=ApprovalManager(db,audit);andx=Android(a.dry_run or cfg.dry_run);voice=LocalVoice(a.dry_run or cfg.dry_run)
 if a.c=='setup': print('Setup complete. Configure .env variables; see docs.'); return 0
 if a.c=='status': print(json.dumps({'dry_run':a.dry_run or cfg.dry_run,'tts':andx.available('termux-tts-speak'),'speech':andx.available('termux-speech-to-text'),'notifications':andx.available('termux-notification-list'),'sms':andx.available('termux-sms-list'),'db':str(cfg.db_path)},indent=2));return 0
 if a.c=='speak': voice.speak(a.text);return 0
 if a.c=='call-owner':
  if not cfg.owner_number: raise SystemExit('Set JARVIS_OWNER_NUMBER in your local environment.')
  print(andx.call(cfg.owner_number));return 0
 if a.c=='call-person': print(json.dumps({'approval_id':ap.create('call-other-person',{'name':a.name,'number':a.number})},indent=2));return 0
 if a.c=='notifications': print(json.dumps(andx.notifications(),indent=2,ensure_ascii=False));return 0
 if a.c=='sms': print(json.dumps(SMSReader(andx).list(),indent=2,ensure_ascii=False));return 0
 if a.c=='whatsapp': print(json.dumps(WhatsAppNotifications(andx).list(),indent=2,ensure_ascii=False));return 0
 if a.c=='email':
  m=MockEmail()
  if a.action=='inbox':print(json.dumps(m.list(),indent=2));return 0
  msg=m.read(a.message_id or '1')
  if not msg:raise SystemExit('Message not found')
  if a.action=='read':print(json.dumps(msg,indent=2));return 0
  if a.action=='summarize':print(msg['body']);return 0
  if a.action=='draft':
   payload={'to':msg['from'],'subject':'Re: '+msg['subject'],'body':'Thank you for your message. I will review this and get back to you.'}
   print('Approval ID:',ap.create('send-email',payload));return 0
 if a.c=='approvals':print(json.dumps(ap.pending(),indent=2));return 0
 if a.c=='approve':
  payload=ap.approve(a.approval_id)
  if payload is False:return 0
  print('Approved. Delivery provider execution is deliberately separate from approval creation.');return 0
 if a.c=='cancel':print(ap.cancel(a.approval_id));return 0
 if a.c=='pune':print(json.dumps(PuneBriefing(cfg).run(a.action),indent=2));return 0
 if a.c=='monitor':print('Monitor framework ready. Configure source adapters before continuous polling.');return 0
 return 0
if __name__=='__main__':main()
