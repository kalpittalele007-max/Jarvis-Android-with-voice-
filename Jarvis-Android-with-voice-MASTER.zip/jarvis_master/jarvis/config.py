from dataclasses import dataclass
from pathlib import Path
import os

@dataclass(frozen=True)
class Config:
    db_path: Path = Path(os.getenv('JARVIS_DB', '~/.jarvis/jarvis.db')).expanduser()
    timezone: str = os.getenv('JARVIS_TIMEZONE', 'Asia/Kolkata')
    owner_number: str = os.getenv('JARVIS_OWNER_NUMBER', '')
    dry_run: bool = os.getenv('JARVIS_DRY_RUN', '0') == '1'
    gmail_token: str = os.getenv('JARVIS_GMAIL_TOKEN', '')
    outlook_token: str = os.getenv('JARVIS_OUTLOOK_TOKEN', '')
    ai_url: str = os.getenv('JARVIS_AI_URL', '')
    ai_key: str = os.getenv('JARVIS_AI_KEY', '')
    ai_model: str = os.getenv('JARVIS_AI_MODEL', '')

    @classmethod
    def load(cls): return cls()
