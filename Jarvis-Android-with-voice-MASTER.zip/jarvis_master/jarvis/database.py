import sqlite3
from pathlib import Path
from datetime import datetime, timezone

SCHEMA='''
CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, provider TEXT, sender TEXT, recipient TEXT, subject TEXT, body TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS email_drafts(id TEXT PRIMARY KEY, data TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS approvals(id TEXT PRIMARY KEY, kind TEXT, payload TEXT, status TEXT, created_at TEXT, expires_at TEXT);
CREATE TABLE IF NOT EXISTS notifications(id TEXT PRIMARY KEY, data TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS pune_events(id TEXT PRIMARY KEY, data TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, data TEXT, status TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS audit_events(id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT, data TEXT, created_at TEXT);
'''
class Database:
    def __init__(self,path:Path):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.cx=sqlite3.connect(self.path); self.cx.row_factory=sqlite3.Row; self.cx.executescript(SCHEMA); self.cx.commit()
    def execute(self,sql,args=()):
        cur=self.cx.execute(sql,args); self.cx.commit(); return cur
    def rows(self,sql,args=()): return [dict(r) for r in self.cx.execute(sql,args)]
