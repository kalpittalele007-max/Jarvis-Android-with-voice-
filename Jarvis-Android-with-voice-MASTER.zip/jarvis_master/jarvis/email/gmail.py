import os,base64,json,urllib.request
from email.message import EmailMessage
class GmailProvider:
    def __init__(self,token=None): self.token=token or os.getenv('JARVIS_GMAIL_TOKEN')
    def _get(self,url):
        if not self.token: raise RuntimeError('JARVIS_GMAIL_TOKEN is not configured')
        r=urllib.request.Request(url,headers={'Authorization':'Bearer '+self.token});
        with urllib.request.urlopen(r,timeout=30) as x:return json.loads(x.read())
    def list(self): return self._get('https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=20')
    def read(self,message_id): return self._get('https://gmail.googleapis.com/gmail/v1/users/me/messages/'+message_id+'?format=full')
    def send(self,payload):
        if not self.token: raise RuntimeError('JARVIS_GMAIL_TOKEN is not configured')
        m=EmailMessage(); m['To']=payload['to']; m['Subject']=payload['subject']; m.set_content(payload['body'])
        raw=base64.urlsafe_b64encode(m.as_bytes()).decode().rstrip('='); data=json.dumps({'raw':raw}).encode()
        req=urllib.request.Request('https://gmail.googleapis.com/gmail/v1/users/me/messages/send',data=data,headers={'Authorization':'Bearer '+self.token,'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=30) as x:return json.loads(x.read())
