from .base import EmailProvider
class MockEmail(EmailProvider):
 def __init__(self): self.data={'1':{'id':'1','from':'alice@example.com','to':'owner@example.com','subject':'Project update','body':'The project meeting is tomorrow at 10 AM.'},'2':{'id':'2','from':'school@example.com','to':'owner@example.com','subject':'Reminder','body':'Please review the attached information.'}}
 def list(self): return list(self.data.values())
 def read(self,message_id): return self.data.get(message_id)
 def send(self,payload): return {'mock':True,'sent':False,'payload':payload}
