import os,urllib.request,json
class OutlookProvider:
 def __init__(self,token=None): self.token=token or os.getenv('JARVIS_OUTLOOK_TOKEN')
 def _req(self,url):
  if not self.token: raise RuntimeError('JARVIS_OUTLOOK_TOKEN is not configured')
  r=urllib.request.Request(url,headers={'Authorization':'Bearer '+self.token});
  with urllib.request.urlopen(r,timeout=30) as x:return json.loads(x.read())
 def list(self): return self._req('https://graph.microsoft.com/v1.0/me/messages?$top=20')
 def read(self,message_id): return self._req('https://graph.microsoft.com/v1.0/me/messages/'+message_id)
 def send(self,payload):
  if not self.token: raise RuntimeError('JARVIS_OUTLOOK_TOKEN is not configured')
  body={'message':{'subject':payload['subject'],'body':{'contentType':'Text','content':payload['body']},'toRecipients':[{'emailAddress':{'address':payload['to']}}]},'saveToSentItems':True}
  req=urllib.request.Request('https://graph.microsoft.com/v1.0/me/sendMail',data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+self.token,'Content-Type':'application/json'},method='POST')
  with urllib.request.urlopen(req,timeout=30) as x:return {'status':x.status}
