class MockAI:
 def summarize(self,text): return text[:500]
 def classify(self,text): return 'general'
 def detect_urgency(self,text): return any(x in text.lower() for x in ('urgent','asap','emergency'))
 def extract_actions(self,text): return []
 def draft_reply(self,text): return 'Thank you for your message. I will review this and get back to you.'
 def summarize_pune_data(self,data): return 'Pune briefing: '+str(len(data))+' source records.'
