class BriefingJob:
 def __init__(self,briefing): self.briefing=briefing
 def run(self): return self.briefing.run()
