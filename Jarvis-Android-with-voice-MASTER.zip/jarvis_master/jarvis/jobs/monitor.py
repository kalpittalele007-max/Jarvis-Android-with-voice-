import time,signal
class Monitor:
 def __init__(self,interval=300): self.interval=interval; self.stop=False; signal.signal(signal.SIGINT,self._stop)
 def _stop(self,*_): self.stop=True
 def run(self,fn):
  while not self.stop:
   try: fn()
   except Exception as e: print('monitor error:',e)
   time.sleep(self.interval)
