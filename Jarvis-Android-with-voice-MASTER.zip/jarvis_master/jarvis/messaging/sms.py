class SMSReader:
 def __init__(self,android): self.android=android
 def list(self): return self.android.sms()
