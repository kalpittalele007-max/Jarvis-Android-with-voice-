class WhatsAppBusinessProvider:
    """Official WhatsApp Business Platform adapter boundary. No private-app scraping."""
    def send(self,payload): raise NotImplementedError('Configure the official WhatsApp Business Platform adapter.')
