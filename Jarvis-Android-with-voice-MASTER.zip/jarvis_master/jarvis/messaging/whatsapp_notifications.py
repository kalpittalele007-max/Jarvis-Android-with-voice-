class WhatsAppNotifications:
 def __init__(self,android): self.android=android
 def list(self): return [x for x in self.android.notifications() if isinstance(x,dict) and x.get('packageName')=='com.whatsapp']
