class CivicSource:
    def fetch(self): return []
