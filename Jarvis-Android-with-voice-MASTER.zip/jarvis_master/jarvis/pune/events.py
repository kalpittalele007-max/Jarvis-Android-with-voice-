class EventsSource:
    def fetch(self): return []
