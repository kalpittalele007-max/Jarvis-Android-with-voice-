class NewsSource:
    def fetch(self): return []
