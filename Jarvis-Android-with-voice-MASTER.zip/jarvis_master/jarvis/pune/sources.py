from dataclasses import dataclass
@dataclass
class SourceRecord:
 name:str; url:str; timestamp:str; location:str; status:str; data:object=None
