class TrafficSource:
    def fetch(self): return []
