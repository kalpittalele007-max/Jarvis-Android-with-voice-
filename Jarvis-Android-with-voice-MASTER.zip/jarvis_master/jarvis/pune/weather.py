class WeatherSource:
    def fetch(self): return []
