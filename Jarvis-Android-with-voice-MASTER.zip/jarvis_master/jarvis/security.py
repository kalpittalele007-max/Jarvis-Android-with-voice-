import re
SECRET_KEY=re.compile(r'(?i)(api[_-]?key|token|password|secret|authorization)\s*[:=]\s*[^\s,}]+')
PHONE=re.compile(r'(?<!\d)\+?[1-9]\d{7,14}(?!\d)')
def redact(x):
    if isinstance(x,dict): return {k: ('[REDACTED]' if re.search(r'(?i)(key|token|password|secret|authorization)',k) else redact(v)) for k,v in x.items()}
    if isinstance(x,list): return [redact(v) for v in x]
    if isinstance(x,str): return PHONE.sub('[PHONE]',SECRET_KEY.sub('[SECRET]',x))
    return x
def untrusted(text): return {'content':text,'trusted':False}
def validate_phone(number):
    if not PHONE.fullmatch(number or ''): raise ValueError('Invalid international phone number. Example: +919876543210')
