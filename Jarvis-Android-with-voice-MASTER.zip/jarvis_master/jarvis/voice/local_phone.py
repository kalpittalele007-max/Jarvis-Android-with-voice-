import shutil,subprocess
class LocalVoice:
    def __init__(self,dry_run=False): self.dry_run=dry_run
    def speak(self,text):
        print('JARVIS:',text)
        if self.dry_run or not shutil.which('termux-tts-speak'): return {'dry_run':self.dry_run,'available':shutil.which('termux-tts-speak') is not None}
        return subprocess.run(['termux-tts-speak','-r','0.85','-p','0.75',text],capture_output=True,text=True).returncode
    def listen(self):
        if not shutil.which('termux-speech-to-text'): return input('You: ')
        return subprocess.run(['termux-speech-to-text'],capture_output=True,text=True,timeout=60).stdout.strip()
