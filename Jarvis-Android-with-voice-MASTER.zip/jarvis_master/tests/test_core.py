import tempfile
from pathlib import Path
from jarvis.database import Database
from jarvis.audit import Audit
from jarvis.approvals import ApprovalManager

def manager():
 p=Path(tempfile.mkdtemp())/'x.db'; db=Database(p); return ApprovalManager(db,Audit(db))
def test_approval_created(): assert manager().create('send-email',{'to':'a@example.com','body':'x'})
def test_cancel():
 a=manager(); i=a.create('send-message',{'to':'x','body':'y'}); assert a.cancel(i)
def test_pending():
 a=manager(); a.create('call-other-person',{'number':'+919999999999'}); assert len(a.pending())==1
