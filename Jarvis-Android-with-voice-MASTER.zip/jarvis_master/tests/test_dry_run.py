from jarvis.android import Android
def test_dry_run(): assert Android(True).call('+919876543210')['dry_run'] is True
