from jarvis.email.mock import MockEmail
def test_mock_email():
 m=MockEmail(); assert m.list(); assert m.read('1')['subject']
