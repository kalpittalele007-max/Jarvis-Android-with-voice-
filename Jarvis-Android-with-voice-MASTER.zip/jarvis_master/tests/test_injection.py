from jarvis.intelligence.openai_compatible import OpenAICompatible
# Contract test: provider system instruction explicitly treats external text as untrusted.
def test_provider_has_injection_guard():
 import inspect
 assert 'UNTRUSTED EXTERNAL DATA' in inspect.getsource(OpenAICompatible.ask)
