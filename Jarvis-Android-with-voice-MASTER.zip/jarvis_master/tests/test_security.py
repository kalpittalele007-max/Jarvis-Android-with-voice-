from jarvis.security import redact,validate_phone
import pytest

def test_secret_redaction(): assert 'SECRET' not in redact('api_key=SECRET').replace('[SECRET]','')
def test_phone_validation(): validate_phone('+919876543210')
def test_bad_phone():
 with pytest.raises(ValueError): validate_phone('123')
